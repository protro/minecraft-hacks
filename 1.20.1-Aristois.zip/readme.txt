== How to install Aristois ==

1. Make sure the Minecraft launcher and Minecraft is closed
2. Copy the folder in this zip file to .minecraft/versions/
3. Start the Minecraft launcher and click "Installations"
4. Press the button that says "New..."
5. Enter any name, and click the "VERSION" dropdown and select "release <mcversion>-Aristois", then click "Create"
6. Go back to the "Play" tab and select Aristois in the version selection to the left of the "PLAY" button
7. Start Aristois 

Note: You may get a warning saying that you are about to start a modified version of Aristois, this is safe to ignore.

== How to find .minecraft/versions/ ==

1. Press Win+R
2. Type %appdata% and press enter
3. Go into the .minecraft folder
4. Go into the versions folder

== Need more help? ==

Send us an email at help@aristois.net and we will provide assistance.
